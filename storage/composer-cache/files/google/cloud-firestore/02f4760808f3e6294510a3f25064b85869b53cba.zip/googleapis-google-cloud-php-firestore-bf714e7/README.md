# Cloud Firestore for PHP

> Idiomatic PHP client for [Cloud Firestore](https://cloud.google.com/firestore/).

[![Latest Stable Version](https://poser.pugx.org/google/cloud-firestore/v/stable)](https://packagist.org/packages/google/cloud-firestore) [![Packagist](https://img.shields.io/packagist/dm/google/cloud-firestore.svg)](https://packagist.org/packages/google/cloud-firestore)

* [API documentation](https://cloud.google.com/php/docs/reference/cloud-firestore/latest)

**NOTE:** This repository is part of [Google Cloud PHP](https://github.com/googleapis/google-cloud-php). Any
support requests, bug reports, or development contributions should be directed to
that project.

A NoSQL document database built for automatic scaling, high performance, and
ease of application development. While the Cloud Firestore interface has many of
the same features as traditional databases, as a NoSQL database it differs from
them in the way it describes relationships between data objects.

### Installation

To begin, install the preferred dependency manager for PHP, [Composer](https://getcomposer.org/).

Now install this component:

```sh
$ composer require google/cloud-firestore
```

This component requires the gRPC extension. Please see our [gRPC installation guide](https://cloud.google.com/php/grpc)
for more information on how to configure the extension.

### Authentication

Please see our [Authentication guide](https://github.com/googleapis/google-cloud-php/blob/main/AUTHENTICATION.md) for more information
on authenticating your client. Once authenticated, you'll be ready to start making requests.

### Sample

```php
use Google\ApiCore\ApiException;
use Google\Cloud\Firestore\V1\Client\FirestoreClient;
use Google\Cloud\Firestore\V1\Document;
use Google\Cloud\Firestore\V1\GetDocumentRequest;

// Create a client.
$firestoreClient = new FirestoreClient();

// Prepare the request message.
$request = (new GetDocumentRequest())
    ->setName($name);

// Call the API and handle any network failures.
try {
    /** @var Document $response */
    $response = $firestoreClient->getDocument($request);
    printf('Response data: %s' . PHP_EOL, $response->serializeToJsonString());
} catch (ApiException $ex) {
    printf('Call failed with message: %s' . PHP_EOL, $ex->getMessage());
}
```

### Debugging

Please see our [Debugging guide](https://github.com/googleapis/google-cloud-php/blob/main/DEBUG.md)
for more information about the debugging tools.

### Version

This component is considered GA (generally available). As such, it will not introduce backwards-incompatible changes in
any minor or patch releases. We will address issues and requests with the highest priority.

### Next Steps

1. Understand the [official documentation](https://cloud.google.com/firestore/docs/).
2. Take a look at [in-depth usage samples](https://github.com/GoogleCloudPlatform/php-docs-samples/tree/master/firestore).
